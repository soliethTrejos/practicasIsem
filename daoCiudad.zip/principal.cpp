#include<iostream>
#include "daoCiudad.cpp"
#include <locale.h>

using namespace std;

int main()
{
    /* code */
    setlocale(LC_ALL, "spanish");
    principal();
    return 0;
}
