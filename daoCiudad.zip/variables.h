#define MAX_REG 100

struct CIUDAD {
    int id;
    char nombre[50];
    char descripcion[100];
};